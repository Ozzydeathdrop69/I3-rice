#!/usr/bin/env python3
import i3ipc

TERMINAL_CLASSES = {"kitty", "Alacritty", "wezterm"}

i3 = i3ipc.Connection()

def update_terminal_borders():
    tree = i3.get_tree()
    for ws in tree.workspaces():
        terminals = [w for w in ws.leaves() if w.window_class in TERMINAL_CLASSES]
        if len(terminals) <= 1:
            for term in terminals:
                term.command('border none')
        else:
            for term in terminals:
                term.command('border pixel 1')

update_terminal_borders()

def on_change(i3, event):
    update_terminal_borders()

i3.on("window::new", on_change)
i3.on("window::close", on_change)
i3.on("window::move", on_change)
i3.on("workspace::focus", on_change)

i3.main()

